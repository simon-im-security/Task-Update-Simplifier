import SwiftUI

@main
struct TaskUpdateSimplifierApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

struct ContentView: View {
    // State variables for task management
    @State private var taskName = ""
    @State private var platform = ""
    @State private var issue = ""
    @State private var solution = ""
    @State private var comment = ""
    @State private var nextSteps = ""
    @State private var userFullName = ""
    @State private var userPosition = ""
    @State private var userEmail = ""
    @State private var userPhone = ""
    @State private var showSaveConfirmation = false
    @State private var saveLocation = ""
    @State private var generatedComment = ""
    @State private var generatedCommentWithoutTaskLine = ""
    @State private var rememberUserDetails = false
    
    private let userDetailsFile = FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Documents/Task-Update-Simplifier/userDetails.txt")

    var body: some View {
        VStack {
            // Buttons for New and Load Task
            HStack {
                Button(action: {
                    resetForm()
                }) {
                    Text("New Task")
                        .padding()
                        .frame(maxWidth: .infinity)
                }

                Button(action: {
                    loadTask()
                }) {
                    Text("Load Task")
                        .padding()
                        .frame(maxWidth: .infinity)
                }
            }
            .padding()

            Form {
                // Task Details
                Section(header: Text("Brief Task Details")) {
                    TextField("Platform", text: $platform)
                        .onChange(of: platform) { newValue in
                            taskName = "\(platform) - \(issue) - \(solution)"
                        }
                    TextField("Issue", text: $issue)
                        .onChange(of: issue) { newValue in
                            taskName = "\(platform) - \(issue) - \(solution)"
                        }
                    TextField("Solution", text: $solution)
                        .onChange(of: solution) { newValue in
                            taskName = "\(platform) - \(issue) - \(solution)"
                        }
                }

                // Comment Details
                Section(header: Text("Comment")) {
                    TextField("", text: $comment)
                }

                // Next Steps
                Section(header: Text("Next Steps")) {
                    TextField("", text: $nextSteps)
                }

                // User Details
                Section(header: Text("Your Details")) {
                    TextField("Full Name", text: $userFullName)
                    TextField("Position", text: $userPosition)
                    TextField("Email", text: $userEmail)
                    TextField("Phone", text: $userPhone)
                    
                    Toggle("Remember User Details", isOn: $rememberUserDetails)
                        .onChange(of: rememberUserDetails) { value in
                            if value {
                                saveUserDetails()
                            } else {
                                deleteUserDetails()
                            }
                        }
                }
            }
            .padding()

            // Display Comment Button
            HStack {
                Button("Display Comment") {
                    generateComment()
                }
                .padding()

                // Save Task Entry Button
                Button("Save Task Entry") {
                    saveTask()
                }
                .padding()

                // Open Folder Button
                Button("Open Folder") {
                    openSaveFolder()
                }
                .padding()
            }

            // Display the generated comment
            if !generatedComment.isEmpty {
                Text("Generated Comment")
                    .font(.headline)
                    .padding(.top)
                
                HStack {
                    // Display the full generated comment
                    VStack {
                        Text("Full Comment")
                            .font(.subheadline)
                        ScrollView {
                            Text(generatedComment)
                                .padding()
                                .background(Color.gray.opacity(0.2))
                                .cornerRadius(10)
                        }
                        Button("Copy Full Comment") {
                            let pasteboard = NSPasteboard.general
                            pasteboard.clearContents()
                            pasteboard.setString(generatedComment, forType: .string)
                        }
                        .padding()
                    }

                    // Display the comment without the "Task" line
                    VStack {
                        Text("Comment without Task Line")
                            .font(.subheadline)
                        ScrollView {
                            Text(generatedCommentWithoutTaskLine)
                                .padding()
                                .background(Color.gray.opacity(0.2))
                                .cornerRadius(10)
                        }
                        Button("Copy Comment") {
                            let pasteboard = NSPasteboard.general
                            pasteboard.clearContents()
                            pasteboard.setString(generatedCommentWithoutTaskLine, forType: .string)
                        }
                        .padding()
                    }
                }
                .padding()
                .frame(height: 200)
                
                Button("Cancel") {
                    generatedComment = ""
                    generatedCommentWithoutTaskLine = ""
                }
                .padding()
            }
        }
        .padding()
        .onAppear(perform: loadUserDetails)
        .alert(isPresented: $showSaveConfirmation) {
            Alert(
                title: Text("File Saved"),
                message: Text("File saved successfully at \(saveLocation)"),
                dismissButton: .default(Text("OK"))
            )
        }
    }

    // Function to generate the comment
    private func generateComment() {
        generatedComment = """
        Task: \(platform) | \(issue) | \(solution)
        Comment: \(comment)
        Next Steps: \(nextSteps)
        
        \(userFullName.isEmpty ? "" : userFullName) \(userPosition.isEmpty ? "" : " | \(userPosition)") \(userEmail.isEmpty ? "" : " | \(userEmail)") \(userPhone.isEmpty ? "" : " | \(userPhone)")
        """
        
        generatedCommentWithoutTaskLine = """
        Comment: \(comment)
        Next Steps: \(nextSteps)
        
        \(userFullName.isEmpty ? "" : userFullName) \(userPosition.isEmpty ? "" : " | \(userPosition)") \(userEmail.isEmpty ? "" : " | \(userEmail)") \(userPhone.isEmpty ? "" : " | \(userPhone)")
        """
    }

    // Function to save the task locally
    private func saveTask() {
        let fileManager = FileManager.default
        let homeDirectory = fileManager.homeDirectoryForCurrentUser
        let documentsURL = homeDirectory.appendingPathComponent("Documents")
        let saveDirectory = documentsURL.appendingPathComponent("Task-Update-Simplifier")
        let filename = taskName.isEmpty ? "Untitled Task" : taskName
        let saveURL = saveDirectory.appendingPathComponent("\(filename).txt")

        do {
            if !fileManager.fileExists(atPath: saveDirectory.path) {
                try fileManager.createDirectory(at: saveDirectory, withIntermediateDirectories: true, attributes: nil)
            }

            var content = generateSaveContent()
            if fileManager.fileExists(atPath: saveURL.path) {
                let existingContent = try String(contentsOf: saveURL, encoding: .utf8)
                content = "\(existingContent)\n\n\(content)"
            }

            try content.write(to: saveURL, atomically: true, encoding: .utf8)
            saveLocation = saveURL.path
            showSaveConfirmation = true
        } catch {
            print("Failed to save file: \(error.localizedDescription)")
        }
    }

    // Function to generate the content to be saved
    private func generateSaveContent() -> String {
        """
        #### Saved on: \(Date())
        TaskName: \(taskName.isEmpty ? "Untitled Task" : taskName)
        Platform: \(platform)
        Issue: \(issue)
        Solution: \(solution)
        Comment: \(comment)
        NextSteps: \(nextSteps)
        UserFullName: \(userFullName)
        UserPosition: \(userPosition)
        UserEmail: \(userEmail)
        UserPhone: \(userPhone)
        """
    }

    // Function to load a task file
    private func loadTask() {
        let panel = NSOpenPanel()
        panel.allowedFileTypes = ["txt"]
        panel.allowsMultipleSelection = false

        if panel.runModal() == .OK, let fileURL = panel.url {
            do {
                let taskDetails = try String(contentsOf: fileURL, encoding: .utf8)
                let lines = taskDetails.split(separator: "\n").map { String($0) }

                for line in lines {
                    if line.contains("TaskName") {
                        taskName = extractValue(from: line)
                    } else if line.contains("Platform") {
                        platform = extractValue(from: line)
                    } else if line.contains("Issue") {
                        issue = extractValue(from: line)
                    } else if line.contains("Solution") {
                        solution = extractValue(from: line)
                    } else if line.contains("Comment") {
                        comment = extractValue(from: line)
                    } else if line.contains("NextSteps") {
                        nextSteps = extractValue(from: line)
                    } else if line.contains("UserFullName") {
                        userFullName = extractValue(from: line)
                    } else if line.contains("UserPosition") {
                        userPosition = extractValue(from: line)
                    } else if line.contains("UserEmail") {
                        userEmail = extractValue(from: line)
                    } else if line.contains("UserPhone") {
                        userPhone = extractValue(from: line)
                    }
                }
            } catch {
                print("Failed to load task: \(error.localizedDescription)")
            }
        }
    }

    // Function to save user details
    private func saveUserDetails() {
        let userDetails = """
        UserFullName: \(userFullName)
        UserPosition: \(userPosition)
        UserEmail: \(userEmail)
        UserPhone: \(userPhone)
        """
        do {
            try userDetails.write(to: userDetailsFile, atomically: true, encoding: .utf8)
        } catch {
            print("Failed to save user details: \(error.localizedDescription)")
        }
    }

    // Function to load user details
    private func loadUserDetails() {
        if FileManager.default.fileExists(atPath: userDetailsFile.path) {
            do {
                let userDetails = try String(contentsOf: userDetailsFile, encoding: .utf8)
                let lines = userDetails.split(separator: "\n").map { String($0) }

                for line in lines {
                    if line.contains("UserFullName") {
                        userFullName = extractValue(from: line)
                    } else if line.contains("UserPosition") {
                        userPosition = extractValue(from: line)
                    } else if line.contains("UserEmail") {
                        userEmail = extractValue(from: line)
                    } else if line.contains("UserPhone") {
                        userPhone = extractValue(from: line)
                    }
                }
                rememberUserDetails = true
            } catch {
                print("Failed to load user details: \(error.localizedDescription)")
            }
        }
    }

    // Function to delete user details
    private func deleteUserDetails() {
        do {
            try FileManager.default.removeItem(at: userDetailsFile)
        } catch {
            print("Failed to delete user details: \(error.localizedDescription)")
        }
    }

    // Helper function to extract value from a line
    private func extractValue(from line: String) -> String {
        guard let range = line.range(of: ": ") else { return "" }
        return String(line[range.upperBound...]).trimmingCharacters(in: .whitespacesAndNewlines)
    }

    // Function to open the save folder
    private func openSaveFolder() {
        let fileManager = FileManager.default
        let homeDirectory = fileManager.homeDirectoryForCurrentUser
        let documentsURL = homeDirectory.appendingPathComponent("Documents")
        let saveDirectory = documentsURL.appendingPathComponent("Task-Update-Simplifier")
        
        NSWorkspace.shared.open(saveDirectory)
    }

    // Function to reset the form for a new task
    private func resetForm() {
        taskName = ""
        platform = ""
        issue = ""
        solution = ""
        comment = ""
        nextSteps = ""
        userFullName = ""
        userPosition = ""
        userEmail = ""
        userPhone = ""
        generatedComment = ""
        generatedCommentWithoutTaskLine = ""
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .frame(width: 1024, height: 768) // Set a large frame size to simulate full-screen
            .edgesIgnoringSafeArea(.all)
    }
}
